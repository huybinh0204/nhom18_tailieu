<?php
include "host.php";
$quey_sel = "SELECT * FROM chude";
$data = mysqli_query($conn,$quey_sel);
class chude_SELECT_get{
	function chude_SELECT_get($id,$TenChuDe,$HinhChuDe){
		$this ->id = $id;
		$this ->TenChuDe = $TenChuDe;
		$this ->HinhChuDe = $HinhChuDe;
	}
}
$chude_SELECT_sql =  array();
while ($row = mysqli_fetch_assoc($data)) {
	array_push($chude_SELECT_sql,new chude_SELECT_get(
		$row['id'],
		$row['TenChuDe'],	
		$row['HinhChuDe']
	));
}
echo json_encode($chude_SELECT_sql);
?>