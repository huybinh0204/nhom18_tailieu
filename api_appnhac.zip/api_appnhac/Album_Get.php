<?php
include "host.php";
$quey_sel = "SELECT * FROM album";
$data = mysqli_query($conn,$quey_sel);
class album_SELECT_get{
	function album_SELECT_get($id,$TenAlbum,$TenCaSiAlbum,$HinhAlbum){
		$this ->id = $id;
		$this ->TenAlbum = $TenAlbum;
		$this ->TenCaSiAlbum = $TenCaSiAlbum;
		$this ->HinhAlbum = $HinhAlbum;
	}
}
$album_SELECT_sql =  array();
while ($row = mysqli_fetch_assoc($data)) {
	array_push($album_SELECT_sql,new album_SELECT_get(
		$row['id'],
		$row['TenAlbum'],	
		$row['TenCaSiAlbum'],
		$row['HinhAlbum']
	));
}
echo json_encode($album_SELECT_sql);
?>