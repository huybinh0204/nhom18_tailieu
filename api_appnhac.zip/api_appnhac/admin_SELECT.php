<?php
include "host.php";
$quey_sel = "SELECT * FROM admin";
$data = mysqli_query($conn,$quey_sel);
class product_shop_SELECT{
	function product_shop_SELECT($id,$username,$password){
		$this ->id = $id;
		$this ->username = $username;
		$this ->password = $password;
	}
}
$product_shop_sel =  array();
while ($row = mysqli_fetch_assoc($data)) {
	array_push($product_shop_sel,new product_shop_SELECT(
		$row['id'],
		$row['username'],	
		$row['password']
	));
}
echo json_encode($product_shop_sel);
?>