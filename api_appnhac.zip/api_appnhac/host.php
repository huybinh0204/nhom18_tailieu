<?php
	$host = "localhost";
	$username="id12222186_binh";
	$password = "123456";
	$database = "id12222186_nhacvip";
	$conn  = mysqli_connect($host,$username,$password,$database);
	mysqli_query($conn,"SET NAMES 'utf8'");
	// if ($conn) {
	// 	echo " Thanh Cong";
	// }else {
	// 	echo " hat Bai";
	// }


?>