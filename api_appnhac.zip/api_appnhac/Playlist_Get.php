<?php
include "host.php";
$quey_sel = "SELECT * FROM playlist";
$data = mysqli_query($conn,$quey_sel);
class playlist_SELECT_get{
	function playlist_SELECT_get($id,$TenPlayList,$HinhNenPlayList,$InconPlayList){
		$this ->id = $id;
		$this ->TenPlayList = $TenPlayList;
		$this ->HinhNenPlayList = $HinhNenPlayList;
		$this ->InconPlayList = $InconPlayList;
	}
}
$playlist_SELECT_sql =  array();
while ($row = mysqli_fetch_assoc($data)) {
	array_push($playlist_SELECT_sql,new playlist_SELECT_get(
		$row['id'],
		$row['TenPlayList'],	
		$row['HinhNenPlayList'],
		$row['InconPlayList']
	));
}
echo json_encode($playlist_SELECT_sql);
?>