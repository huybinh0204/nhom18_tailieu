<?php
include "host.php";
$quey_sel = "SELECT * FROM theloai";
$data = mysqli_query($conn,$quey_sel);
class theloai_SELECT_get{
	function theloai_SELECT_get($id,$idChude,$ThenTheLoai,$HinhTheLoai){
		$this ->id = $id;
		$this ->idChude = $idChude;
		$this ->ThenTheLoai = $ThenTheLoai;
		$this ->HinhTheLoai = $HinhTheLoai;
		
	}
}
$theloai_SELECT_sql =  array();
while ($row = mysqli_fetch_assoc($data)) {
	array_push($theloai_SELECT_sql,new theloai_SELECT_get(
		$row['id'],
		$row['idChude'],	
		$row['ThenTheLoai'],
		$row['HinhTheLoai']
	));
}
echo json_encode($theloai_SELECT_sql);
?>