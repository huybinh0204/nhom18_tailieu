<?php
include "host.php";
$quey_sel = "SELECT * FROM baihat";
$data = mysqli_query($conn,$quey_sel);
class baihat_SELECT_get{
	function baihat_SELECT_get($id,$idAlbum,$idTheLoai,$idPlaylist,$TenBaiHat,$HinhBaiHat,$CaSi,$LinkBaiHat,$LuotThich){
		$this ->id = $id;
		$this ->idAlbum = $idAlbum;
		$this ->idTheLoai = $idTheLoai;
		$this ->idPlaylist = $idPlaylist;
		$this ->TenBaiHat = $TenBaiHat;
		$this ->HinhBaiHat = $HinhBaiHat;
		$this ->CaSi = $CaSi;
		$this ->LinkBaiHat = $LinkBaiHat;
		$this ->LuotThich = $LuotThich;
	}
}
$baihat_SELECT_sql =  array();
while ($row = mysqli_fetch_assoc($data)) {
	array_push($baihat_SELECT_sql,new baihat_SELECT_get(
		$row['id'],
		$row['idAlbum'],	
		$row['idTheLoai'],
		$row['idPlaylist'],
		$row['TenBaiHat'],
		$row['HinhBaiHat'],
		$row['CaSi'],
		$row['LinkBaiHat'],
		$row['LuotThich']
	));
}
echo json_encode($baihat_SELECT_sql);
?>