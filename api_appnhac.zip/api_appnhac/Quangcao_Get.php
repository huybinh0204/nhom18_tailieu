<?php
include "host.php";
$quey_sel = "SELECT * FROM quangcao a JOIN baihat b ON a.idbaiHat = b.id";
$data = mysqli_query($conn,$quey_sel);
class quangcao_SELECT_get{
	function quangcao_SELECT_get($id,$TenBaiHat,$HinhBaiHat,$NoiDungQuangCao,$HinhanhQuangCao){
		$this ->id = $id;
		$this ->TenBaiHat = $TenBaiHat;
		$this ->HinhBaiHat = $HinhBaiHat;
		$this ->NoiDungQuangCao = $NoiDungQuangCao;
		$this ->HinhanhQuangCao = $HinhanhQuangCao;
	}
}
$quangcao_SELECT_sql =  array();
while ($row = mysqli_fetch_assoc($data)) {
	array_push($quangcao_SELECT_sql,new quangcao_SELECT_get(
		$row['id'],
		$row['TenBaiHat'],
		$row['HinhBaiHat'],
		$row['NoiDungQuangCao'],
		$row['HinhanhQuangCao']
	));
}
echo json_encode($quangcao_SELECT_sql);
?>